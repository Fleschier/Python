## GetY ##

```python
fpdf.gety()
```
### Description ###

Returns the ordinate of the current position.


### See also ###

[GetX](GetX.md), [SetX](SetX.md), [SetY](SetY.md), [SetXY](SetXY.md).

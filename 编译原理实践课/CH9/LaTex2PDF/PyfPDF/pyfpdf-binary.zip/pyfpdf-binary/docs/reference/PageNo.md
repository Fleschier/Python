## PageNo ##

```python
fpdf.page_no()
```

### Description ###

Returns the current page number.

### See also ###

[AliasNbPages](AliasNbPages.md).

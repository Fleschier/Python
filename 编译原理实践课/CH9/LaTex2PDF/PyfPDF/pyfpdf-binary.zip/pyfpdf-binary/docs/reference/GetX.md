## GetX ##

```python
fpdf.getx()
```
### Description ###

Returns the abscissa of the current position.


### See also ###

[GetY](GetY.md), [SetX](SetX.md), [SetY](SetY.md), [SetXY](SetXY.md).

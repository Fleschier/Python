#!/bin/sh

# prepare local copy for tests

mkdir fpdf_local
mkdir fpdf_local/fpdf

cp ../fpdf/*.py fpdf_local/fpdf/

echo Now you can test:
echo    python runtest.py


